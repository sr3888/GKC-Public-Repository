using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using EmeraldAI;

public class GKC_EmeraldHealthBridge : healthManagement
{
    public bool damageEnabled = true;
    public int ragdollForce = 100;
    public bool criticalHit;

    public EmeraldHealth mainEmeraldHealth;
    public override void setDamageWithHealthManagement (float damageAmount, Vector3 fromDirection, Vector3 damagePos, GameObject attacker, GameObject projectile,
 bool damageConstant, bool searchClosestWeakSpot, bool ignoreShield, bool
 ignoreDamageInScreen, bool damageCanBeBlocked, bool canActivateReactionSystemTemporally,
 int damageReactionID, int damageTypeID)
    {
        if (damageEnabled) {
            mainEmeraldHealth.Damage ((int)damageAmount,
                attacker.transform,
                ragdollForce,
                criticalHit);
        }
    }
}
